<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
    <link rel="stylesheet" href="css/style.css">
    

    <title>Rent N Go</title>
</head>

<body>
    <nav>
        <div class="nt-container">
            <div class="container">
                <div class="nav-top">
                    <div>
                        <i class="fa-solid fa-location-dot"></i>
                        <span>Nueva Ecija, Philippines</span>
                    </div>
                    <div>
                        <i class="fa-solid fa-clock"></i>
                        <span>24/7 Open</span>
                    </div>
                    <div>
                        <i class="fa-solid fa-phone"></i>
                        <span>1234567890</span>
                    </div>
                    <div class="social-icons">
                        <i class="fa-brands fa-facebook"></i>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-linkedin-in"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="n1-container">
            <div class="container">
                <div class="logo">
                    <img src="pic/logo.png" alt="">
                </div>
                <ul class="navlist">
                    <li><a href="#home">home</a></li>
                    <li><a href="#about">about</a></li>
                    <li><a href="#services">services</a></li>
                    <li><a href="#cars">car-list</a></li>
                    <li><a href="login-register.php">login/register</a></li>
                </ul>
                <div class="menu-btn">
                    <i class="fa-solid fa-bars"></i>
                </div>
            </div>
        </div>
    </nav>

    <header class="home" id="home">
        <div class="container home-container">
            <div class="info">
                <h1>Rent A Car is Within your finger tips</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi,
                    officia enim quis neque esse labore soluta commodi fugit consequatur
                    odio. Porro, ex.</p>
                <div class="booking-form">
                    <div class="form-group">
                        <h5>Select Vehicle:</h5>
                        <select name="Car" id="">
                            <option value="">select</option>
                            <option value="">Toyota</option>
                            <option value="">Mitsubishi</option>
                            <option value="">Nissan</option>
                            <option value="">Ford</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <h5>Pick up:</h5>
                        <input type="date" name="Pick Up" placeholder="Pick up">

                    </div>
                    <div class="form-group">
                        <h5>Drop off:</h5>
                        <input type="date" name="Drop-off" placeholder="Drop-off">
                    </div>
                </div>
                <button class="btn">Book</button>

            </div>
        </div>
    </header>

    <!--=================================WORKS==================================================== -->

    <section class="works">
        <div class="title">
            <h3>How it works?</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo autem soluta sed
                mollitia!</p>
        </div>
        <div class="container works-container">
            <div class="step">
                <span class="number">01</span>
                <span class="caption">Select Car Type</span>
            </div>
            <div class="step">
                <span class="number">02</span>
                <span class="caption">Time</span>
            </div>
            <div class="step">
                <span class="number">03</span>
                <span class="caption">Pick n Drop</span>
            </div>
            <div class="step">
                <span class="number">04</span>
                <span class="caption">Check out</span>
            </div>
            <div class="step">
                <span class="number">05</span>
                <span class="caption">Done</span>
            </div>

        </div>
    </section>
    <!--=================================ABOUT==================================================== -->
    <section class="about" id="about">
        <div class="title">
            <h4><i class="fa-solid fa-car"></i></h4>
        </div>
        <div class="about-container">
            <div class="image">
                <img src="pic/about pixels.jpg" alt="">
            </div>
            <div class="content">
                <div class="title">
                    <p>About us</p>
                    <h2>Welcome to Rent N Go</h2>
                    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolor ullam eius nam
                        qui a aut sunt amet aperiam rem velit, quis incidunt! Dolores, reiciendis esse? Odio
                        dolorem sint qui velit laudantium. Est ullam, iure impedit accusamus assumenda, debitis quo
                        voluptates alias voluptate aperiam tenetur.
                    </p> <br>
                    <p style=>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Iusto qui nemo perspiciatis eos
                        a sit,
                        excepturi fuga nam dolore incidunt magnam, quaerat consequuntur sint voluptate expedita
                        recusandae molestias hic
                        quos fugiat unde nesciunt molestiae laborum alias! Veritatis dicta neque vero cupiditate
                        adipisci? Nobis ipsam at
                        obcaecati esse dolorem quaerat corporis commodi mollitia atque! Earum, pariatur molestias! Magni
                        distinctio laborum voluptas corporis aliquam ratione quo vel perspiciatis!</p>
                </div>
            </div>
        </div>
    </section>
    <!--=================================SERVICES==================================================== -->
    <section class="services" id="services">
        <div class="title">
            <h4><i class="fa-solid fa-car"></i></h4>
            <h2>What services we offer to our clients</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita, non quae.</p>
        </div>

        <div class="container services-container">
            <div class="card">
                <div>
                    <span class="lnr lnr-rocket"></span>
                    <h4>Car Accessories</h4>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum, placeat harum.</p>
            </div>
            <div class="card">
                <div>
                    <span class="lnr lnr-license"></span>
                    <h4>Technical Repair</h4>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum, placeat harum.</p>
            </div>
            <div class="card">
                <div>
                    <span class="lnr lnr-user"></span>
                    <h4>Vast Reservation</h4>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum, placeat harum.</p>
            </div>
            <div class="card">
                <div>
                    <span class="lnr lnr-phone"></span>
                    <h4>24/7 Support</h4>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum, placeat harum.</p>
            </div>
            <div class="card">
                <div>
                    <span class="lnr lnr-car"></span>
                    <h4>Rental Cars</h4>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum, placeat harum.</p>
            </div>
            <div class="card">
                <div>
                    <span class="lnr lnr-calendar-full"></span>
                    <h4>Booking System</h4>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatum, placeat harum.</p>
            </div>
        </div>

    </section>
    <!-- ==================================CARS=================================== -->
    <section class="cars" id="cars">
        <div class="title">
            <h4><i class="fa-solid fa-car"></i></h4>
            <h2>Choose Your Car</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita, non quae.</p>
        </div>
        <div class="container cars-container-dets">
            <div class="box">
                <img src="pic\cars pixels (1).jpg" alt="">
                <div class="info">
                    <div class="tag">
                        <span class="lnr lnr-pointer-right"></span>
                        <p>3000/DAY</p>
                    </div>
                    <h5>Challenger</h5>
                    <p>Dodge</p>
                    <div>
                        <a href="car-info.php">2020</a>
                        <a href="">Manual</a>
                        <a href="">AC</a>
                    </div>
                </div>
            </div>
            <div class="box">
                <img src="pic\cars pixels (2).jpg" alt="">
                <div class="info">
                    <div class="tag">
                        <span class="lnr lnr-pointer-right"></span>
                        <p>3000/DAY</p>
                    </div>
                    <h5>Range Rover 2.0</h5>
                    <p>Land Rover</p>
                    <div>
                        <a href="">2020</a>
                        <a href="">Manual</a>
                        <a href="">AC</a>
                    </div>
                </div>
            </div>
            <div class="box">
                <img src="pic\cars pixels (3).jpg" alt="">
                <div class="info">
                    <div class="tag">
                        <span class="lnr lnr-pointer-right"></span>
                        <p>3000/DAY</p>
                    </div>
                    <h5>Huracan</h5>
                    <p>Lamborghini</p>
                    <div>
                        <a href="">2020</a>
                        <a href="">Manual</a>
                        <a href="">AC</a>
                    </div>
                </div>
            </div>
            <div class="box">
                <img src="pic\cars pixels (4).jpg" alt="">
                <div class="info">
                    <div class="tag">
                        <span class="lnr lnr-pointer-right"></span>
                        <p>3000/DAY</p>
                    </div>
                    <h5>Nissan</h5>
                    <p>350z</p>
                    <div>
                        <a href="">2020</a>
                        <a href="">Manual</a>
                        <a href="">AC</a>
                    </div>
                </div>
            </div>
            <div class="box">
                <img src="pic\cars pixels (10).jpg" alt="">
                <div class="info">
                    <div class="tag">
                        <span class="lnr lnr-pointer-right"></span>
                        <p>3000/DAY</p>
                    </div>
                    <h5>McLaren</h5>
                    <p>P1</p>
                    <div>
                        <a href="">2020</a>
                        <a href="">Manual</a>
                        <a href="">AC</a>
                    </div>
                </div>
            </div>
            <div class="box">
                <img src="pic\cars pixels (8).jpg" alt="">
                <div class="info">
                    <div class="tag">
                        <span class="lnr lnr-pointer-right"></span>
                        <p>3000/DAY</p>
                    </div>
                    <h5>SL 350</h5>
                    <p>Mercedez-Benz</p>
                    <div>
                        <a href="">2020</a>
                        <a href="">Manual</a>
                        <a href="">AC</a>
                    </div>
                </div>
            </div>


        </div>
    </section>
    <!-- ==============================BLOG========================================-->

    <section class="blog" id="blog">
        <div class="title">
            <h4><i class="fa-solid fa-car"></i></h4>
            <h2>Blog</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita, non quae.</p>
        </div>
        <div class="container blog-container-bl">
            <div class="card card-1">
                <div class="image">
                    <img src="pic\blog pixels (1).jpg" alt="">
                </div>
                <div class="content">
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quasi iste numquam
                        voluptate dicta laudantium eum veritatis rem officiis. Beatae, vitae! Voluptatum
                        soluta aperiam laborum necessitatibus? Laborum ratione expedita eius explicabo blanditiis
                        nam laboriosam, assumenda quas,
                        cumque vero ipsum dolor aspernatur laudantium, eaque totam! Exercitationem.</p>
                </div>
            </div>
            <div class="card card-2">

                <div class="content">
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quasi iste numquam
                        voluptate dicta laudantium eum veritatis rem officiis. Beatae, vitae! Voluptatum
                        soluta aperiam laborum necessitatibus? Laborum ratione expedita eius explicabo blanditiis
                        nam laboriosam, assumenda quas,
                        cumque vero ipsum dolor aspernatur laudantium, eaque totam! Exercitationem.</p>
                </div>
                <div class="image">
                    <img src="pic\blog pixels (2).jpg" alt="">
                </div>

            </div>
    </section>


<!--=========================================FOOTER======================================-->

<footer>
    <div class="container footer-container">
        <div class="row-1">
            <div class="logo">
                <img src="pic\logo.png" alt="">
            </div>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam consectetur accusantium sint.</p>
        </div>
        <div class="row-2">
            <ul class="quick-links">
                <h4>Quick Links</h4>
                    <li><a href="#about">about</a></li>
                    <li><a href="#services">services</a></li>
                    <li><a href="#car-list">car-list</a></li>

            </ul>
        </div>
        <div class="row-3">
            <ul class="explore">
                <h4>Support</h4>
                    <li style="color: var(--color-primary);"><a href="">Help</a></li>
                    <li style="color: var(--color-primary);"><a href="#services">services</a></li>
                    <li style="color: var(--color-primary);"><a href="#services">Terms & Conditions</a></li>
                    <li style="color: var(--color-primary);"><a href="#services">Privacy Policy</a></li>

            </ul>
        </div>
        <div class="row-4">
            <ul class="explore">
                <h4>Support</h4>
                    <li style="color: var(--color-primary);"><a href="">Contact us</a></li>
                    <li style="color: var(--color-primary);"><a href="#services">0123456789</a></li>
                    <p>dfg@gmail.com</p>
                    <ul class="footer-social">
                        <li class="fa-brands fa-facebook"></li>
                        <li class="fa-brands fa-instagram"></li>
                        <li class="fa-brands fa-twitter"></li>
                        <li class="fa-brands fa-linkedin-in"></li>
                    </ul>

            </ul>
        </div>
    </div>
</footer>
    <script src="https://unpkg.com/scrollreveal"></script>
    <script src="js/script.js"></script>
</body>

</html>