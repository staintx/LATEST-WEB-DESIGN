<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Car Information - Rent N Go</title>
    <style>
    :root {
        --color-primary: #0C2340;
        --color-secondary: #6BABD6;
        --color-text: #FFFFFF;
        --color-bg: #595959;
        --shadow: 0 2px 8px rgba(0, 0, 0, .4);
        --transition: all .4s ease;
    }

    body {
        font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        background-color: var(--color-primary);
        color: var(--color-text);
        line-height: 1.7;
        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    /* Navbar styles */
    nav {
        background: rgba(255, 255, 255, .9);
    }

    .n1-container {
        background-color: rgba(255, 255, 255, .9);
    }

    nav .container {
        display: flex;
        align-items: center;
        justify-content: space-between;
        transition: var(--transition);
    }

    .logo img {
        width: 3rem;
        padding: .5rem 0;
    }

    .navlist {
        display: flex;
        gap: 2.2rem;
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .navlist li a {
        color: var(--color-primary);
        text-transform: uppercase;
        font-weight: 600;
        font-size: .9rem;
        text-decoration: none;
    }

    .navlist li a:hover {
        color: var(--color-secondary);
    }

    .menu-btn {
        font-size: 1.5rem;
        cursor: pointer;
        display: none;
    }

    /* Car info styles */
    .car-info-container {
        max-width: 1200px;
        margin: 20px auto;
    }

    .car-photo {
        background-color: var(--color-secondary);
        height: 400px;
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: hidden;
    }

    .car-photo img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .car-details {
        background-color: var(--color-primary);
        padding: 20px;
    }

    .car-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
    }

    .car-name,
    .car-price {
        font-size: 24px;
        color: var(--color-secondary);
    }

    .car-info {
        display: flex;
        justify-content: space-between;
    }

    .car-overview {
        width: 60%;
    }

    .car-overview h3 {
        color: var(--color-text);
        margin-top: 0;
    }

    .book-now {
        width: 30%;
        display: flex;
        align-items: flex-start;
        justify-content: flex-end;
    }

    .btn-book {
        display: inline-block;
        background-color: var(--color-secondary);
        color: var(--color-primary);
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
        text-transform: uppercase;
    }

    /* Responsive design */
    @media (max-width: 824px) {
        .menu-btn {
            display: block;
        }

        .navlist {
            position: absolute;
            flex-direction: column;
            top: 4rem;
            right: 2rem;
            width: 40%;
            padding: 1rem 0;
            background: rgba(255, 255, 255, .9);
            z-index: 111;
            display: none;
        }

        .active {
            display: flex;
        }
    }

    .btn-book:hover{
    background: var(--color-bg);
    color: var(--color-secondary);
    
}

    </style>
</head>

<body>
    <nav>
        <div class="container">
            <div class="logo">
                <img src="pic/logo.png" alt="Rent N Go Logo">
            </div>
            <ul class="navlist">
                <li><a href="index.php">HOME</a></li>
                <li><a href="#about">ABOUT</a></li>
                <li><a href="#services">SERVICES</a></li>
                <li><a href="index.php#car-list">CAR-LIST</a></li>
                <li><a href="login-register.php">LOGIN/REGISTER</a></li>
            </ul>
        </div>
    </nav>

    <div class="car-info-container">
        <div class="car-photo">
            <img src="pic/cars pixels (3).jpg" alt="Car Photo">
        </div>
        <div class="car-details">
            <div class="car-header">
                <div class="car-name">CAR NAME</div>
                <div class="car-price">PRICE</div>
            </div>
            <div class="car-info">
                <div class="car-overview">
                    <h3>CAR OVERVIEW</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                        laboris nisi ut aliquip ex ea commodo consequat.</p>
                </div>
                <div class="book-now">
                    <a href="#" class="btn-book">BOOK NOW</a>
                </div>
            </div>
        </div>
    </div>
</body>
<script src="https://unpkg.com/scrollreveal"></script>
<script src="js/script.js"></script>


</html>